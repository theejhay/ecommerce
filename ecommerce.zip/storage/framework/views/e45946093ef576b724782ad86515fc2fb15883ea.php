<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>

    <div class="container mt-5">
        <form method="post" action="<?php echo e(route('product.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Product Name</label>
                <input type="text" name="product_name" id="product_name" placeholder="Product Name" class="form-control">
            </div>
            <div class="form-group">
                <label>Quantity in Stock</label>
                <input type="text" name="quantity" id="quantity" placeholder="Quantity in Stock" class="form-control">
            </div>
            <div class="form-group">
                <label>Price Per Item</label>
                <input type="text" name="price" id="price" placeholder="Price Per Item" class="form-control">
            </div>
            <div class="form-group">
                <input type="submit" name="add_product" id="add_product" class="btn btn-success" value="Add Product">
            </div>
        </form>

        <hr>

        <h3>Products</h3>
        <table>
            <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity in Stock</th>
                <th>Price per item</th>
                <th>Date Submitted</th>
                <th>Total Value Number</th>
            </tr>
            </thead>
            <tbody id="product_list">
            <tr>
                <td>Total</td>
                <td>SUM</td>
            </tr>
            </tbody>
        </table>
    </div>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <script>
        $(document).ready(function(){
            $('#add_product').on('click', function(e){
                e.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "<?php echo e(route('product.store')); ?>",
                    method: 'post',
                    data: {
                        product_name: $('#product_name').val(),
                        quantity: $('#type').val(),
                        price: $('#price').val()
                    },
                    success: function(result){
                        loadProducts()
                    }});
            });

            function loadProducts()
            {
                $.get(<?php echo e(route('products')); ?>, function (res) {
                    console.log(res.data)
                    let data = res.data
                    //Object.keys(data).forEach(k => data[k].forEach(e =>))
                })
            }
        });
    </script>
    </body>
</html>
<?php /**PATH /Users/Lexy/PHPProjects/Test2/resources/views/homepage.blade.php ENDPATH**/ ?>